# -*- coding: utf-8 -*-
"""任务三（对比分析）：同一张图上「语义分割」与「实例分割」的差异，以及跨模型一致性。

输出：
    results/figures/T3_<图>_compare.png   原图 / FCN 语义 / Mask R-CNN 实例 / 人-车一致性差异图
    results/figures/T3_iou.png            person / car 两个类的跨模型 IoU
    results/figures/T3_instance_vs_semantic.png  同类多实例（多人合影）的合并问题
    results/json/task3_compare.json

用法：
    .venv\\Scripts\\python.exe src\\task3_compare.py
"""
import sys

import cv2
import numpy as np

import common
import config
import seg_utils

VOC2COCO = {"person": 1, "bicycle": 2, "car": 3, "motorcycle": 4, "bus": 6, "train": 7,
            "dog": 18, "cat": 17, "horse": 20, "sheep": 21, "cow": 22, "bottle": 44,
            "chair": 62, "diningtable": 67, "potted plant": 64, "sofa": 63, "tv": 72}


def iou_binary(a, b):
    inter = np.count_nonzero(a & b)
    union = np.count_nonzero(a | b)
    return float(inter / union) if union else 0.0


def main():
    with common.tee("task3_compare"):
        classes = common.load_names(config.PASCAL_CLASSES)
        coco = common.load_names(config.COCO_CLASSES)
        fcn = seg_utils.FCNSegmenter(config.PROTOTXT, config.CAFFEMODEL, config.FCN_SIZE)
        mrcnn = seg_utils.MaskRCNNSegmenter(config.MASK_PB, config.MASK_PBTXT, config.MASK_CONF)
        colors = seg_utils.generate_color_map(len(classes))

        rows, iou_rows = [], []
        panels, titles = [], []
        for name, desc in config.DEMO_IMAGES:
            img = common.imread(str(config.IMAGES / name))
            fcn_map = fcn.predict(img)["class_map"]
            fcn_mask = seg_utils.generate_mask(fcn_map, colors)
            inst, _ = mrcnn.predict(img, config.MASK_CONF)
            inst = seg_utils.classwise_nms(inst, config.MASK_NMS)
            overlay, _ = seg_utils.draw_instances(img, inst, coco)

            # 每个可映射的类，比较「FCN 的该类区域」与「Mask R-CNN 该类实例并集」的 IoU
            per_class = {}
            for voc_name, coco_id in VOC2COCO.items():
                if voc_name not in classes:
                    continue
                vid_id = classes.index(voc_name)
                a = fcn_map == vid_id
                b = seg_utils.union_mask(inst, coco_id)
                if b is None or not a.any() or not b.any():
                    continue
                b = b.astype(bool)
                iou = iou_binary(a, b)
                per_class[voc_name] = {"iou": round(iou, 4),
                                       "fcn_pixels": int(a.sum()),
                                       "inst_pixels": int(b.sum()),
                                       "instances": sum(1 for i in inst if i["class_id"] == coco_id)}
                iou_rows.append({"image": name, "class": voc_name, "iou": round(iou, 4)})

            # 同类多实例：FCN 的 person 区域连通域个数 vs Mask R-CNN 检出的人数
            person_id = classes.index("person")
            pmask = (fcn_map == person_id).astype(np.uint8)
            n_cc, _ = cv2.connectedComponents(pmask, connectivity=8)
            n_person_ins = sum(1 for i in inst if i["class_id"] == 1)
            n_all = len(inst)
            inst_union = np.any([i["mask"] for i in inst], axis=0) if inst else np.zeros_like(fcn_map, bool)
            rows.append({"image": name, "desc": desc,
                         "fcn_fg_ratio": round(100.0 * np.count_nonzero(fcn_map) / fcn_map.size, 2),
                         "inst_count": n_all,
                         "inst_fg_ratio": round(100.0 * np.count_nonzero(inst_union) / fcn_map.size, 2),
                         "person_instances": n_person_ins,
                         "fcn_person_components": int(n_cc - 1),
                         "per_class": per_class})
            print("\n[%s] %s" % (name, desc))
            print("  FCN 前景 %.1f%% | Mask R-CNN 实例 %d 个（person %d）" % (
                100.0 * np.count_nonzero(fcn_map) / fcn_map.size, n_all, n_person_ins))
            for k, v in per_class.items():
                print("  %-12s IoU(FCN vs 实例并集) = %.3f   实例数 %d" % (k, v["iou"], v["instances"]))
            print("  person 区域连通域 %d 个 vs 实例 %d 个 ← 语义分割会把相邻同类目标连成一片" % (
                n_cc - 1, n_person_ins))

            # 差异图：FCN person(绿) / Mask R-CNN person(红) / 交集(白)
            a = (fcn_map == person_id)
            b = seg_utils.union_mask(inst, 1)
            diff = np.zeros_like(img)
            if b is not None:
                diff[a & ~b] = (0, 255, 0)
                diff[~a & b] = (0, 0, 255)
                diff[a & b] = (255, 255, 255)
            panels += [img, fcn_mask, overlay, diff]
            titles += ["原图 %s" % name, "FCN 语义分割", "Mask R-CNN 实例分割",
                       "person：绿=仅FCN 红=仅MRCNN 白=一致"]

        common.panel_figure(config.FIGURES / "T3_instance_vs_semantic.png", panels, titles,
                            cols=4, figsize=(17.5, 3.1 * len(rows)),
                            title="语义分割 vs 实例分割：同一张图、同样 21/90 类模型，输出语义完全不同")

        # IoU 柱状图
        import matplotlib.pyplot as plt
        common.setup_plot()
        cls = sorted({r["class"] for r in iou_rows})
        fig, ax = plt.subplots(figsize=(8.4, 3.6))
        width = 0.8 / max(len(cls), 1)
        for k, c in enumerate(cls):
            xs = [i for i, r in enumerate(iou_rows) if r["class"] == c]
            ys = [iou_rows[i]["iou"] for i in xs]
            ax.bar([i + k * width for i in xs], ys, width=width, label=c)
        ax.set_xticks(range(len(iou_rows)))
        ax.set_xticklabels(["%s\n%s" % (r["image"].replace(".jpg", ""), r["class"]) for r in iou_rows],
                           rotation=60, fontsize=7)
        ax.set_ylabel("IoU")
        ax.set_ylim(0, 1)
        ax.set_title("同一类别下 FCN 语义区域与 Mask R-CNN 实例并集的一致性")
        ax.legend(fontsize=8)
        fig.savefig(str(config.FIGURES / "T3_iou.png"), dpi=110)
        plt.close(fig)
        print("\n[fig ] %s" % (config.FIGURES / "T3_iou.png"))

        ious = [r["iou"] for r in iou_rows]
        summary = {"pairs": iou_rows,
                   "mean_iou": round(float(np.mean(ious)), 4),
                   "median_iou": round(float(np.median(ious)), 4),
                   "images": rows}
        common.save_json(summary, config.JSONS / "task3_compare.json")
        print("\n跨模型 IoU 平均 %.3f / 中位数 %.3f（%d 个 图-类 组合）" % (
            summary["mean_iou"], summary["median_iou"], len(ious)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
