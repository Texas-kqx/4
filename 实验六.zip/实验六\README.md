# 实验六 语义分割与实例分割

本仓库是《分割实验报告》的**完整实现 + 实验报告**。所有数字都在本机实测，
每个数字都能在 `results/json/` 查回，每张图在 `results/figures/`。

- 报告：**[实验报告.md](实验报告.md)** / `实验报告.docx`
- 源码：`src/task1_*`（FCN8s 语义分割）、`src/task2_*`（Mask R-CNN 实例分割）、`src/task3_*`（两者对比）

---

## 1. 做了什么

**任务一：语义分割（OpenCV `cv2.dnn` + FCN8s / Pascal VOC 21 类）**

| 内容 | 脚本 | 结果 |
|---|---|---|
| 加载 class/model/config，打印 `score.shape` | `src/task1_semantic_fcn.py` | 输出 `(1,21,500,500)`，logits ∈ [-8.42, 20.66] |
| 像素分类 `get_class_map` | `src/seg_utils.py` | `squeeze(0)` + `argmax(axis=0)`，6 张图 375×500 ~ 1080×810 |
| 调色板 / 掩码 / 融合 | `src/seg_utils.py` | 等分色相 21 色，背景黑；`addWeighted` 与「只融合前景」两版 |
| 6 张演示图 | 同上 | 平均 预处理 2.97 / 前向 773.8 / 后处理 97.2 ms（CPU） |
| 对照实验：减不减 VOC 均值 | 同上 | 像素一致率 85.3%~98.3%，zidane 前景 43.3% → 29.9% |

**任务二：实例分割（Mask R-CNN / COCO 90 类）**

| 内容 | 脚本 | 结果 |
|---|---|---|
| 读模型（frozen graph → pbtxt） | `tools/build_mask_graph.py` | `readNetFromTensorflow(pb)` 直接崩，须先生成 185 KB 文本图 |
| 前向 + 解析输出 | `src/task2_instance_maskrcnn.py` | `[1,1,100,7]` + `[100,90,15,15]` |
| 15×15 掩码缩放贴回 + 两级 NMS | `src/seg_utils.py` | 6 张图 27 个实例（person 18 / car 7 / motorcycle 1 / bus 1） |
| 速度 | 同上 | 前向 1756 ms、后处理 6.8 ms（CPU，原分辨率） |

**任务三：同一张图上语义 vs 实例**

| 内容 | 脚本 | 结果 |
|---|---|---|
| 跨模型 IoU（FCN 类区域 vs 实例并集） | `src/task3_compare.py` | 平均 0.541 / 中位数 0.605（10 组） |
| 同类多实例粘连 | 同上 | zidane：1 个连通域 vs 2 个实例；004091：4 个 vs 6 个 |

![FCN8s 语义分割 6 张结果](results/figures/T1_all_results.png)

---

## 2. 目录结构

```
实验六/
├── 实验报告.md / 实验报告.docx
├── README.md / requirements.txt
├── 原始文档/                       ← 实验文档原样存档
├── src/                            ← 算法 + 三个任务脚本 + 环境自检
├── tools/                          ← 下载 / 生成 pbtxt / 一键运行 / md→docx
├── images/                         ← 6 张演示图
├── weights/                        ← 模型（不进提交包，约 690 MB）
└── results/
    ├── figures/  json/  logs/
    └── summary_tables.md
```

---

## 3. 安装与运行

```powershell
# 1) 依赖（opencv 必须 4.x；5.x 删了 caffe/tf importer）
pip install -r requirements.txt

# 2) 模型（caffemodel 走 16 线程分段下载，约 6~7 分钟）
python tools\download_models.py

# 3) Mask R-CNN 文本图（一次即可）
python tools\build_mask_graph.py

# 4) 跑实验（或 powershell -File tools\run_all.ps1 一键）
python src\env_check.py
python src\task1_semantic_fcn.py
python src\task2_instance_maskrcnn.py
python src\task3_compare.py

# 5) 生成 docx
python tools\md2docx.py 实验报告.md 实验报告.docx
```

---

## 4. 模型与数据（不入库，需自己准备）

| 文件 | 大小 | 来源 |
|---|---|---|
| `weights/fcn8s-heavy-pascal.caffemodel` | 513.0 MB | `http://dl.caffe.berkeleyvision.org/fcn8s-heavy-pascal.caffemodel`（单连接 32 KB/s，脚本用 16 线程分段） |
| `weights/fcn8s-heavy-pascal.prototxt` | 8.5 KB | opencv_extra 的 `testdata/dnn/` |
| `weights/mask_rcnn_inception_v2_coco_2018_01_28/` | 64.0 MB | `http://download.tensorflow.org/models/object_detection/...tar.gz` |
| `weights/mask_rcnn.pbtxt` | 185 KB | `tools/build_mask_graph.py` 生成 |
| `weights/pascal-classes.txt`、`coco_classes.txt` | — | 脚本生成 |

演示图：`bus.jpg`、`zidane.jpg`（ultralytics 示例图）+ 4 张 VOC2007 图像。

---

## 5. 工程上的四个坑（换机器/换目录一定会再遇到）

1. **中文路径**：目录叫「实验六」，`cv2.imread` 直接返回 `None`、`cv2.dnn.readNetFromCaffe` 报
   `Failed to open NetParameter file`。解决：`common.imread`（`fromfile`+`imdecode`）、
   `common.dnn_path`（模型复制到 ASCII 临时目录，按大小缓存；513 MB 只拷一次）。
2. **Mask R-CNN 不能直接读 frozen graph**：`readNetFromTensorflow(pb)` 挂在
   `graph_simplifier.cpp` 的 `nodeIds.find(inpName)` 断言上。必须先用
   `tools/build_mask_graph.py`（内部就是 OpenCV 官方的 `tf_text_graph_mask_rcnn.py`）生成 pbtxt。
   而且 `writeTextGraph` 吞异常，写到中文路径只会得到空文件。
3. **类号 0 基 vs 1 基**：重写后的图输出 0 基类号（0=person），按 1 基解释会得到
   「公交→airplane、车→bicycle、人被当背景过滤」。修正：`cid = raw_cid + 1`，掩码通道仍用 `raw_cid`。
4. **`addWeighted(图0.4, 掩码0.6)` 会把背景压暗**：掩码背景是黑色，被一起加权。
   报告里给了「只在前景像素上融合」的改进版，两种结果都留了图。

---

## 6. 复现性说明

- 耗时是单张串行、CPU 32 线程实测，随机器负载波动 ±10%。
- OpenCV DNN 多线程浮点累加顺序不固定，Mask R-CNN 的实例数可能 **±1**（阈值附近的框会翻转）。
  需要完全可复现时设 `cv2.setNumThreads(1)`。
