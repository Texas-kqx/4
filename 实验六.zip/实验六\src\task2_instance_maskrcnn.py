# -*- coding: utf-8 -*-
"""任务二（实例分割）：Mask R-CNN / OpenCV DNN 完整流程。

流程（与语义分割对照）：
    1. 读取模型、配置文件、类别文件      cv2.dnn.readNetFromTensorflow(frozen_inference_graph.pb)
    2. 读取图像、归一化、前向传播        blobFromImage(swapRB=True) → 1×3×H×W → forward
    3. 从模型输出中获取结果              输出是「框 + 每框一个小掩码」，不是整图类别图
    4. 结果可视化                        掩码上色 + 轮廓 + 框 + 类别标签

用法：
    .venv\\Scripts\\python.exe src\\task2_instance_maskrcnn.py [--conf 0.5]
"""
import argparse
import sys
import time

import cv2
import numpy as np

import common
import config
import seg_utils


def build_net():
    """1. 读取模型、配置文件（frozen graph 自带结构）、类别文件。

    注意：TF Object Detection API 的 frozen graph 不能直接 readNetFromTensorflow(pb)，
    会死在 graph_simplifier 的断言上；必须配合 tools/build_mask_graph.py 生成的文本图 pbtxt。
    """
    print("[model] %s (%.1f MB)" % (config.MASK_PB.parent.name,
                                    config.MASK_PB.stat().st_size / 2 ** 20))
    print("[graph] %s (%.1f KB)" % (config.MASK_PBTXT.name,
                                    config.MASK_PBTXT.stat().st_size / 2 ** 10))
    net = cv2.dnn.readNetFromTensorflow(common.dnn_path(config.MASK_PB),
                                        common.dnn_path(config.MASK_PBTXT))
    names = common.load_names(config.COCO_CLASSES)
    print("[names] coco_classes.txt → %d 类（第 0 个是 __background__）" % len(names))
    return net, names


def inspect_output(net, image):
    """第 2/3 节：看输出结构，说明实例分割与语义分割的差别。"""
    print("\n=== 模型输出结构 ===")
    print("输入图 %s" % (image.shape,))
    blob = cv2.dnn.blobFromImage(image, swapRB=True, crop=False)
    print("blob  = %s（swapRB=True：TF 按 RGB 训练，cv2 是 BGR；不做均值缩放，模型内部自带）" % (blob.shape,))
    net.setInput(blob)
    t0 = time.perf_counter()
    boxes, masks = net.forward(["detection_out_final", "detection_masks"])
    ms = (time.perf_counter() - t0) * 1000
    print("detection_out_final = %s   [batch, ?, N, (img_id, class_id, conf, x1,y1,x2,y2)]" % (boxes.shape,))
    print("detection_masks     = %s   [N, 类数, m, m]（每个候选框一张 15×15 的框内小掩码）" % (masks.shape,))
    print("前向耗时 %.1f ms" % ms)
    n_keep = int((boxes[0, 0, :, 2] > 0.5).sum())
    print("置信度 > 0.5 的候选框：%d / %d（其余是背景或低分框，需要过滤）" % (n_keep, boxes.shape[2]))
    print("→ 语义分割输出 [1,21,H,W] 是「每像素的类别得分」；")
    print("→ 实例分割输出是「每个目标一个框 + 一张小掩码 + 类别 + 分数」，需要逐实例缩放掩码再贴回原图。")
    return boxes, masks, ms, blob.shape


def run_one(net, names, name, desc, conf_thr, timer=None):
    image = common.imread(str(config.IMAGES / name))
    if image is None:
        print("[skip] 读不到 %s" % name)
        return None, None
    t0 = time.perf_counter()
    blob = cv2.dnn.blobFromImage(image, swapRB=True, crop=False)
    t1 = time.perf_counter()
    net.setInput(blob)
    boxes, masks = net.forward(["detection_out_final", "detection_masks"])
    t2 = time.perf_counter()
    raw_instances = seg_utils.decode_maskrcnn(image, boxes, masks, conf_thr)
    instances = seg_utils.classwise_nms(raw_instances, config.MASK_NMS)
    t3 = time.perf_counter()
    if timer is not None:
        timer.add("preprocess", (t1 - t0) * 1000)
        timer.add("forward", (t2 - t1) * 1000)
        timer.add("postprocess", (t3 - t2) * 1000)

    overlay, mask_only = seg_utils.draw_instances(image, instances, names, alpha=0.5)
    tag = name.rsplit(".", 1)[0]
    common.imwrite(config.FIGURES / ("T2_%s_overlay.png" % tag), overlay)
    if len(instances):
        common.panel_figure(config.FIGURES / ("T2_%s_pipeline.png" % tag),
                            [image, mask_only, overlay],
                            ["原图（%s）" % desc, "实例掩码（每实例一色）", "掩码+框+类别（叠加 0.5）"],
                            cols=3, figsize=(13.5, 3.6))
    cnt = {}
    for ins in instances:
        nm = names[ins["class_id"]] if ins["class_id"] < len(names) else str(ins["class_id"])
        cnt[nm] = cnt.get(nm, 0) + 1
    print("\n[%s] %s  实例 %d 个（NMS 前 %d）  前向 %.0f ms  后处理 %.0f ms" % (
        name, desc, len(instances), len(raw_instances), (t2 - t1) * 1000, (t3 - t2) * 1000))
    print("    类别分布：%s" % (cnt if cnt else "无"))
    for ins in instances[:6]:
        x1, y1, x2, y2 = ins["box"]
        print("    %-12s %.3f  box=(%4d,%4d,%4d,%4d)  面积占比 %.2f%%" % (
            names[ins["class_id"]], ins["score"], x1, y1, x2, y2, ins["area_ratio"]))
    rec = {"image": name, "desc": desc, "shape": list(image.shape),
           "num_raw": len(raw_instances), "num_instances": len(instances),
           "class_count": cnt,
           "ms": {"preprocess": round((t1 - t0) * 1000, 2),
                  "forward": round((t2 - t1) * 1000, 2),
                  "postprocess": round((t3 - t2) * 1000, 2)},
           "instances": [{"class": names[i["class_id"]], "score": round(i["score"], 4),
                          "box": i["box"], "area_ratio": i["area_ratio"]} for i in instances]}
    return rec, instances


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--conf", type=float, default=config.MASK_CONF)
    args = ap.parse_args()
    for d in (config.FIGURES, config.JSONS, config.LOGS):
        d.mkdir(parents=True, exist_ok=True)

    with common.tee("task2_instance_maskrcnn"):
        net, names = build_net()
        first = common.imread(str(config.IMAGES / config.DEMO_IMAGES[1][0]))
        boxes, masks, ms, blob_shape = inspect_output(net, first)

        timer = common.Timer()
        results, all_inst = [], {}
        for name, desc in config.DEMO_IMAGES:
            rec, inst = run_one(net, names, name, desc, args.conf, timer)
            if rec:
                results.append(rec)
                all_inst[name] = inst

        # 汇总：每个类别的实例总数
        total = {}
        for rec in results:
            for k, v in rec["class_count"].items():
                total[k] = total.get(k, 0) + v
        total_sorted = sorted(total.items(), key=lambda t: -t[1])
        print("\n=== 全部演示图的实例统计 ===")
        for k, v in total_sorted:
            print("  %-14s %d" % (k, v))

        # 类别分布柱状图
        import matplotlib.pyplot as plt
        common.setup_plot()
        fig, ax = plt.subplots(figsize=(7.6, 3.6))
        ax.bar([k for k, _ in total_sorted], [v for _, v in total_sorted], color="#3b7dd8")
        ax.set_ylabel("实例数")
        ax.set_title("Mask R-CNN 在演示图上的实例类别分布（conf ≥ %.2f）" % args.conf)
        plt.xticks(rotation=25, fontsize=8)
        fig.savefig(str(config.FIGURES / "T2_class_count.png"), dpi=110)
        plt.close(fig)
        print("[fig ] %s" % (config.FIGURES / "T2_class_count.png"))

        # 速度图
        fig, ax = plt.subplots(figsize=(7.6, 3.4))
        xs = np.arange(len(results))
        pre = [r["ms"]["preprocess"] for r in results]
        fwd = [r["ms"]["forward"] for r in results]
        post = [r["ms"]["postprocess"] for r in results]
        ax.bar(xs, pre, label="预处理")
        ax.bar(xs, fwd, bottom=pre, label="前向")
        ax.bar(xs, post, bottom=np.array(pre) + np.array(fwd), label="后处理(掩码缩放)")
        ax.set_xticks(xs)
        ax.set_xticklabels([r["image"] for r in results], rotation=15, fontsize=8)
        ax.set_ylabel("ms")
        ax.set_title("Mask R-CNN 各阶段耗时（CPU，输入为原图分辨率）")
        ax.legend(fontsize=8)
        fig.savefig(str(config.FIGURES / "T2_speed.png"), dpi=110)
        plt.close(fig)
        print("[fig ] %s" % (config.FIGURES / "T2_speed.png"))

        common.save_json({"model": {"pb": str(config.MASK_PB),
                                    "pb_mb": round(config.MASK_PB.stat().st_size / 2 ** 20, 1),
                                    "conf_thr": args.conf, "nms_iou": config.MASK_NMS},
                          "blob_shape_first": list(blob_shape),
                          "output": {"detection_out_final": list(boxes.shape),
                                     "detection_masks": list(masks.shape)},
                          "forward_ms_first": round(ms, 2),
                          "timing": timer.summary(),
                          "class_total": dict(total_sorted),
                          "images": results},
                         config.JSONS / "task2_instance_maskrcnn.json")

        print("\n%-18s %5s %5s %10s %10s" % ("image", "raw", "keep", "forward", "post"))
        for r in results:
            print("%-18s %5d %5d %10.1f %10.1f" % (
                r["image"], r["num_raw"], r["num_instances"],
                r["ms"]["forward"], r["ms"]["postprocess"]))
        print("\n平均：%s" % timer.summary())
    return 0


if __name__ == "__main__":
    sys.exit(main())
