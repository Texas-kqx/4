# -*- coding: utf-8 -*-
"""实验六 分割核心算法：语义分割（FCN8s）的像素分类 / 可视化，以及 Mask R-CNN 的实例后处理。

本文件对应实验报告里的三个 TODO：
    get_class_map(score)            —— 第 2 节「实现像素分类」
    generate_color_map(num_classes) —— 第 3 节「分割结果可视化」
    generate_mask(class_map, colors)
另外把两个模型封装成类，便于脚本复用与计时。
"""
import cv2
import numpy as np

import common


# ================================================================== 一、语义分割
def get_class_map(score):
    """把 [1, C, H, W] 的逐像素得分图变成 [H, W] 的类别图。

    输入：
        score: [1, 21, H, W]  —— FCN8s 的原始输出（未归一化的 logits，21 = 20 类 + 背景）
    输出：
        class_map: [H, W] uint8 —— 每个像素的类别 ID
    """
    # TODO 1：去掉 batch 维度 —— [1,21,H,W] → [21,H,W]
    score = np.squeeze(score, axis=0)

    # TODO 2：获取每个像素预测得分最高的类别 —— 在“类别通道”维（axis=0）上取 argmax
    #        注意不是 axis=-1：这里通道在前（NCHW），axis=-1 会在宽度方向上取最大值。
    class_map = np.argmax(score, axis=0)

    return class_map.astype(np.uint8)


def generate_color_map(num_classes):
    """为每一个类别生成一个颜色（BGR，uint8），返回 [num_classes, 3]。

    做法：在 HSV 色相环上把 [0,180) 等分成 num_classes-1 份（背景占 0 号），
    亮度和饱和度交替取值，避免相邻类别颜色过于接近；最后把背景（类别 0）设为黑色。
    等分色相的好处是可预测：21 类时 0 号黑、7 号（car）约 54° 绿、15 号（person）约 125° 蓝紫，
    叠加时人、车一眼能分开（黄金角取色在这个类数下反而会让 car / person 撞成同一种绿）。
    """
    colors = np.zeros((num_classes, 3), np.uint8)
    n = max(num_classes - 1, 1)
    for i in range(1, num_classes):
        hue = int(round(179.0 * (i - 1) / n))
        val = 255 if i % 2 else 205
        hsv = np.uint8([[[hue, 240, val]]])
        colors[i] = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)[0, 0]
    # TODO：背景类别设置为黑色
    colors[0] = (0, 0, 0)
    return colors


def generate_mask(class_map, colors):
    """按类别 ID 查表上色。

    输入：
        class_map: [H, W] 类别 ID
        colors:    [C, 3] 调色板
    输出：
        mask: [H, W, 3] BGR 彩色掩码（背景为纯黑）
    """
    # 花式索引：一次查表完成，等价于逐像素 mask[y, x] = colors[class_map[y, x]]
    return colors[class_map.astype(np.int32)]


def blend_mask(image, mask, alpha=0.4, beta=0.6):
    """实验报告里的融合公式：cv2.addWeighted(image, 0.4, mask, 0.6, 0)。

    缺点：背景是黑色 (0,0,0)，按 0.6 的权重加权会把整张原图压暗到 40% 亮度。
    """
    return cv2.addWeighted(image, alpha, mask, beta, 0)


def blend_foreground(image, mask, class_map, alpha=0.5):
    """改进版融合：只在前景像素上叠加颜色，背景保留原图亮度。"""
    out = image.copy()
    fg = class_map > 0
    colored = cv2.addWeighted(image, 1.0 - alpha, mask, alpha, 0)
    out[fg] = colored[fg]
    return out


def mask_contours(mask, thickness=1):
    """在 mask 上画类别边界，便于看清分割边缘。"""
    out = mask.copy()
    for cid in np.unique(mask.reshape(-1, 3), axis=0):
        if not np.any(cid):
            continue
        m = np.all(mask == cid[None, None, :], axis=2).astype(np.uint8)
        cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(out, cnts, -1, (255, 255, 255), thickness)
    return out


def class_area_stats(class_map, names):
    """统计各类别像素占比（%），只返回出现过的类别。"""
    total = class_map.size
    ids, cnts = np.unique(class_map, return_counts=True)
    rows = []
    for i, c in zip(ids, cnts):
        rows.append({"id": int(i), "name": names[i], "pixels": int(c),
                     "ratio": round(100.0 * c / total, 3)})
    rows.sort(key=lambda r: -r["pixels"])
    return rows


class FCNSegmenter:
    """FCN8s（caffe）封装：预处理 → 前向 → 得分图 → 像素分类。"""

    def __init__(self, prototxt, caffemodel, size=(500, 500), use_mean=True):
        self.size = tuple(size)
        self.use_mean = use_mean
        self.net = cv2.dnn.readNetFromCaffe(common.dnn_path(prototxt), common.dnn_path(caffemodel))
        self.net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
        self.net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)

    def forward(self, image):
        """返回 [21, h, w] 的 logits（h,w = prototxt 里的输入尺寸）。"""
        h, w = self.size[1], self.size[0]
        mean = (104.00698793, 116.66876762, 122.67891434) if self.use_mean else (0, 0, 0)
        blob = cv2.dnn.blobFromImage(image, scalefactor=1.0, size=(w, h), mean=mean,
                                     swapRB=False, crop=False)
        self.net.setInput(blob)
        score = self.net.forward()          # [1, 21, h, w]
        return score

    def predict(self, image, resize_logits=True):
        """完整推理：返回 dict(score, class_map, probs)。

        class_map 与输入图同分辨率：先把 21 通道 logits 双线性插值回原图大小再 argmax
        （等价于对每类的 soft 得分上采样，比先 argmax 再最近邻放大的锯齿更少）。
        """
        score = self.forward(image)
        prob = np.squeeze(score, axis=0)                 # [21, h, w]
        if resize_logits:
            h, w = image.shape[:2]
            prob = cv2.resize(prob.transpose(1, 2, 0), (w, h),
                              interpolation=cv2.INTER_LINEAR).transpose(2, 0, 1)
        prob = np.ascontiguousarray(prob)
        class_map = get_class_map(prob[None, ...])       # [H, W]
        return {"score": score, "class_map": class_map, "logits": prob}


# ================================================================== 二、实例分割
class MaskRCNNSegmenter:
    """Mask R-CNN（TensorFlow frozen graph）封装。

    与语义分割的关键区别：网络输出的是「框 + 每个框对应的小掩码」，
    而不是整图逐像素类别图。
        detection_out_final: [1, 1, N, 7] = [batch, ?, det, (img_id, class_id, conf, x1, y1, x2, y2)]
                             其中坐标是相对原图宽高的归一化值
        detection_masks:     [N, C, m, m]（这里是 [100, 90, 15, 15]，90 = COCO 类数 + 背景，m=15）
    """

    def __init__(self, pb_path, pbtxt_path=None, conf_thr=0.5):
        pb = common.dnn_path(pb_path)
        pbtxt = common.dnn_path(pbtxt_path) if pbtxt_path else ""
        self.net = cv2.dnn.readNetFromTensorflow(pb, pbtxt)
        self.conf_thr = conf_thr

    def forward(self, image):
        # swapRB=True：TF 模型按 RGB 训练，而 cv2 读进来是 BGR
        blob = cv2.dnn.blobFromImage(image, swapRB=True, crop=False)
        self.net.setInput(blob)
        boxes, masks = self.net.forward(["detection_out_final", "detection_masks"])
        return boxes, masks

    def predict(self, image, conf_thr=None):
        """返回 (instances, raw)：instances 为每实例的 dict 列表。"""
        boxes, masks = self.forward(image)
        conf = self.conf_thr if conf_thr is None else conf_thr
        return decode_maskrcnn(image, boxes, masks, conf), (boxes, masks)


def decode_maskrcnn(image, boxes, masks, conf_thr=0.5):
    """第 3 步的核心：把 [1,1,N,7] + [N,90,15,15] 变成每实例的框/掩码/类别/分数。

    实例分割的输出和语义分割完全不同，必须逐实例处理：
        1) 置信度过滤；
        2) 归一化框坐标 × 原图宽高 → 像素框；
        3) 取该实例对应类别的那张 m×m 小掩码，resize 到「框的大小」；
        4) 阈值 0.5 二值化，再贴回整图（框外恒为 0）。
    """
    H, W = image.shape[:2]
    if masks.ndim == 3:                     # 少数导出会少一维，补成 [N,1,h,w]
        masks = masks[:, None]
    num = boxes.shape[2]
    instances = []
    for i in range(num):
        conf = float(boxes[0, 0, i, 2])
        if conf < conf_thr:
            continue
        # 类号：这个重写后的图在 90 类上做 softmax 再 argmax，输出是 0 基索引
        # （0=person, 1=bicycle, 2=car ...），而 COCO/TF 的标签 id 是 1 基（1=person）。
        # 掩码通道用 0 基索引，显示/统计用 1 基 id，两者差 1。
        raw_cid = int(boxes[0, 0, i, 1])
        if raw_cid < 0 or raw_cid >= masks.shape[1]:
            continue
        cid = raw_cid + 1
        x1 = int(round(np.clip(boxes[0, 0, i, 3] * W, 0, W - 1)))
        y1 = int(round(np.clip(boxes[0, 0, i, 4] * H, 0, H - 1)))
        x2 = int(round(np.clip(boxes[0, 0, i, 5] * W, 0, W - 1)))
        y2 = int(round(np.clip(boxes[0, 0, i, 6] * H, 0, H - 1)))
        if x2 <= x1 + 1 or y2 <= y1 + 1:
            continue
        # 每个实例只有一张 15×15 的“框内掩码”，要缩放到框大小、二值化，再贴回全图
        m = masks[i, raw_cid]
        m = cv2.resize(m, (x2 - x1, y2 - y1), interpolation=cv2.INTER_LINEAR)
        m = (m > 0.5)
        full = np.zeros((H, W), np.uint8)
        full[y1:y2, x1:x2] = m.astype(np.uint8)
        instances.append({"class_id": cid, "score": conf,
                          "box": [x1, y1, x2, y2],
                          "mask": full.astype(bool),
                          "area_ratio": round(100.0 * full.sum() / (H * W), 3)})
    instances.sort(key=lambda r: -r["score"])
    return instances


# ------------------------------------------------------------------ 实例可视化
_INST_PALETTE = [
    (56, 56, 255), (151, 157, 255), (31, 112, 255), (29, 178, 255), (49, 210, 207),
    (10, 249, 72), (23, 204, 146), (134, 219, 61), (52, 147, 26), (187, 212, 0),
    (168, 153, 44), (255, 194, 0), (147, 69, 52), (255, 115, 100), (236, 24, 0),
    (255, 56, 132), (133, 0, 82), (255, 56, 203), (200, 149, 255), (199, 55, 255),
]


def instance_color(i):
    return _INST_PALETTE[i % len(_INST_PALETTE)]


def draw_instances(image, instances, names, alpha=0.5, show_score=True, thick=2):
    """画「掩码 + 轮廓 + 框 + 标签」。返回 (叠加图, 纯掩码图)。"""
    overlay = image.copy()
    mask_only = np.zeros_like(image)
    for k, ins in enumerate(instances):
        col = instance_color(k)
        m = ins["mask"]
        overlay[m] = cv2.addWeighted(image, 1 - alpha, np.full_like(image, col), alpha, 0)[m]
        mask_only[m] = col
        cnts, _ = cv2.findContours(m.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(overlay, cnts, -1, col, 1)
        cv2.drawContours(mask_only, cnts, -1, col, 1)
        x1, y1, x2, y2 = ins["box"]
        cv2.rectangle(overlay, (x1, y1), (x2, y2), col, thick)
        name = names[ins["class_id"]] if ins["class_id"] < len(names) else str(ins["class_id"])
        label = ("%s %.2f" % (name, ins["score"])) if show_score else name
        (tw, th), base = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        y0 = max(0, y1 - th - 4)
        cv2.rectangle(overlay, (x1, y0), (x1 + tw + 2, y0 + th + base), col, -1)
        cv2.putText(overlay, label, (x1 + 1, y0 + th + 1), cv2.FONT_HERSHEY_SIMPLEX,
                    0.5, (0, 0, 0), 1, cv2.LINE_AA)
    return overlay, mask_only


def classwise_nms(instances, iou_thr=0.3, cross_iou=0.7):
    """先做同类 NMS，再跨类别去重：同一个目标被不同类别重复框出时只保留分数最高的。"""
    keep = []
    for cid in sorted({ins["class_id"] for ins in instances}):
        group = [ins for ins in instances if ins["class_id"] == cid]
        group.sort(key=lambda r: -r["score"])
        while group:
            best = group.pop(0)
            keep.append(best)
            rest = []
            for other in group:
                if _iou_boxes(best["box"], other["box"]) <= iou_thr:
                    rest.append(other)
            group = rest
    keep.sort(key=lambda r: -r["score"])
    final = []
    for ins in keep:
        if all(_iou_boxes(ins["box"], f["box"]) <= cross_iou for f in final):
            final.append(ins)
    return final


def _iou_boxes(a, b):
    ix1, iy1 = max(a[0], b[0]), max(a[1], b[1])
    ix2, iy2 = min(a[2], b[2]), min(a[3], b[3])
    iw, ih = max(0, ix2 - ix1), max(0, iy2 - iy1)
    inter = iw * ih
    ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / ua if ua > 0 else 0.0


def union_mask(instances, class_id=None):
    """把若干实例掩码并成一张二值图（可选只取某一类）。"""
    if not instances:
        return None
    h, w = instances[0]["mask"].shape
    out = np.zeros((h, w), bool)
    for ins in instances:
        if class_id is not None and ins["class_id"] != class_id:
            continue
        out |= ins["mask"]
    return out
