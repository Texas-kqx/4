# -*- coding: utf-8 -*-
"""下载实验六需要的模型文件（FCN8s / Mask R-CNN / 类名表）。

单连接只有 30 KB/s 的源（caffe.berkeleyvision.org）改成分段多线程下载：
512 MB 的 caffemodel 从「4.5 小时」降到「7 分钟」。

用法：
    .venv\\Scripts\\python.exe tools\\download_models.py [--only fcn|mask|names] [--jobs 12]

放置位置：
    weights/fcn8s-heavy-pascal.prototxt / .caffemodel   语义分割 FCN8s（Pascal VOC 21 类）
    weights/pascal-classes.txt                          VOC 21 类名
    weights/mask_rcnn_inception_v2_coco_2018_01_28.tar.gz → 解压出 frozen_inference_graph.pb
"""
import argparse
import hashlib
import json
import os
import sys
import tarfile
import threading
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WEIGHTS = ROOT / "weights"
JSONS = ROOT / "results" / "json"
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) experiment6/1.0"}

MASK_TAR = "mask_rcnn_inception_v2_coco_2018_01_28.tar.gz"
MASK_DIR = "mask_rcnn_inception_v2_coco_2018_01_28"

FILES = {
    "fcn8s-heavy-pascal.prototxt": (
        "fcn8s-heavy-pascal.prototxt", 8_000,
        ["https://raw.githubusercontent.com/opencv/opencv_extra/master/testdata/dnn/fcn8s-heavy-pascal.prototxt"],
        "FCN8s 网络结构 (caffe prototxt, 21 类)"),
    "fcn8s-heavy-pascal.caffemodel": (
        "fcn8s-heavy-pascal.caffemodel", 537_963_413,
        ["http://dl.caffe.berkeleyvision.org/fcn8s-heavy-pascal.caffemodel"],
        "FCN8s 权重 (VGG16 backbone, 513 MB)"),
    MASK_TAR: (
        MASK_TAR, 177_817_887,
        ["http://download.tensorflow.org/models/object_detection/" + MASK_TAR],
        "Mask R-CNN InceptionV2 (COCO) frozen graph"),
}

PASCAL_CLASSES = ["background", "aeroplane", "bicycle", "bird", "boat", "bottle", "bus",
                  "car", "cat", "chair", "cow", "diningtable", "dog", "horse",
                  "motorbike", "person", "pottedplant", "sheep", "sofa", "train", "tvmonitor"]

COCO_CLASSES = [
    "__background__", "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train",
    "truck", "boat", "traffic light", "fire hydrant", "street sign", "stop sign",
    "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep", "cow", "elephant",
    "bear", "zebra", "giraffe", "hat", "backpack", "umbrella", "shoe", "eye glasses",
    "handbag", "tie", "suitcase", "frisbee", "skis", "snowboard", "sports ball", "kite",
    "baseball bat", "baseball glove", "skateboard", "surfboard", "tennis racket", "bottle",
    "plate", "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple",
    "sandwich", "orange", "broccoli", "carrot", "hot dog", "pizza", "donut", "cake",
    "chair", "couch", "potted plant", "bed", "mirror", "dining table", "window", "desk",
    "toilet", "door", "tv", "laptop", "mouse", "remote", "keyboard", "cell phone",
    "microwave", "oven", "toaster", "sink", "refrigerator", "blender", "book", "clock",
    "vase", "scissors", "teddy bear", "hair drier", "toothbrush"]


def sha256(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(chunk), b""):
            h.update(b)
    return h.hexdigest()


def _head(url):
    req = urllib.request.Request(url, headers=UA, method="HEAD")
    with urllib.request.urlopen(req, timeout=30) as r:
        return int(r.headers.get("Content-Length") or 0), r.headers.get("Accept-Ranges", "")


def fetch_parallel(url, dst, jobs=12):
    """分段并发下载：每个线程负责一段 Range，写进同一个文件的对应偏移。"""
    total, ranges = _head(url)
    if not total:
        return fetch_stream(url, dst)
    print("   size %.1f MB, ranges=%s, jobs=%d" % (total / 2 ** 20, ranges, jobs), flush=True)
    part = total // jobs + 1
    segs = [(i * part, min(total - 1, (i + 1) * part - 1)) for i in range(jobs)]
    lock = threading.Lock()
    done = [0]
    err = []
    f = open(dst, "wb")
    f.truncate(total)
    f.close()

    def worker(idx, a, b):
        for attempt in range(3):
            try:
                req = urllib.request.Request(url, headers=dict(UA, Range="bytes=%d-%d" % (a, b)))
                with urllib.request.urlopen(req, timeout=120) as r, open(dst, "r+b") as fh:
                    fh.seek(a)
                    while True:
                        buf = r.read(1 << 20)
                        if not buf:
                            break
                        fh.write(buf)
                        with lock:
                            done[0] += len(buf)
                            if done[0] % (64 << 20) < (1 << 20):
                                print("   %6.1f/%.1f MB" % (done[0] / 2 ** 20, total / 2 ** 20),
                                      flush=True)
                return
            except Exception as e:  # noqa: BLE001
                if attempt == 2:
                    with lock:
                        err.append("%s: %s" % (type(e).__name__, e))
                time.sleep(2)

    ths = [threading.Thread(target=worker, args=(i, a, b)) for i, (a, b) in enumerate(segs)]
    t0 = time.time()
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    if err:
        raise RuntimeError("分段下载失败：" + "; ".join(err))
    got = os.path.getsize(dst)
    print("   ok %.1f MB in %.1f s (%.1f MB/s)" % (
        got / 2 ** 20, time.time() - t0, got / 2 ** 20 / max(time.time() - t0, 1e-9)), flush=True)
    if got != total:
        raise RuntimeError("大小不符：%d != %d" % (got, total))
    return got


def fetch_stream(url, dst):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=120) as r:
        total = int(r.headers.get("Content-Length") or 0)
        done, t0 = 0, time.time()
        with open(dst, "wb") as f:
            while True:
                b = r.read(1 << 20)
                if not b:
                    break
                f.write(b)
                done += len(b)
                if total and done % (32 << 20) < (1 << 20):
                    print("   %6.1f/%.1f MB" % (done / 2 ** 20, total / 2 ** 20), flush=True)
    return done


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default=None, help="fcn | mask | names")
    ap.add_argument("--jobs", type=int, default=12)
    args = ap.parse_args()
    WEIGHTS.mkdir(parents=True, exist_ok=True)
    JSONS.mkdir(parents=True, exist_ok=True)
    log = {}
    if (JSONS / "downloads.json").exists():
        log = json.loads((JSONS / "downloads.json").read_text(encoding="utf-8"))

    # 类名表本地生成
    if not args.only or "names" in args.only:
        (WEIGHTS / "pascal-classes.txt").write_text("\n".join(PASCAL_CLASSES) + "\n", encoding="utf-8")
        (WEIGHTS / "coco_classes.txt").write_text("\n".join(COCO_CLASSES) + "\n", encoding="utf-8")
        print("[make] pascal-classes.txt (%d) / coco_classes.txt (%d)" % (
            len(PASCAL_CLASSES), len(COCO_CLASSES)))

    for key, (fn, expect, urls, desc) in FILES.items():
        if args.only and args.only not in key:
            continue
        dst = WEIGHTS / fn
        if dst.exists() and dst.stat().st_size >= expect * 0.99:
            print("[skip] %s 已存在 (%.2f MB)" % (fn, dst.stat().st_size / 2 ** 20))
            continue
        if dst.exists():
            dst.unlink()
        print("[get ] %s  <- %s" % (fn, desc))
        ok = False
        part = dst.with_suffix(dst.suffix + ".part")
        for url in urls:
            try:
                print("   try %s" % url, flush=True)
                if "caffemodel" in fn:
                    n = fetch_parallel(url, part, args.jobs)
                else:
                    n = fetch_stream(url, part)
                if n < expect * 0.9:
                    raise RuntimeError("too small: %d" % n)
                os.replace(str(part), str(dst))
                ok = True
                break
            except Exception as e:  # noqa: BLE001
                print("   FAIL %s: %s" % (type(e).__name__, e))
                if part.exists():
                    part.unlink()
        if not ok:
            print("[ERR ] %s 下载失败" % fn)
            continue
        log[fn] = {"bytes": dst.stat().st_size, "sha256": sha256(dst), "desc": desc, "url": url}
        (JSONS / "downloads.json").write_text(json.dumps(log, ensure_ascii=False, indent=2),
                                              encoding="utf-8")

    tar = WEIGHTS / MASK_TAR
    out = WEIGHTS / MASK_DIR
    if tar.exists() and not (out / "frozen_inference_graph.pb").exists():
        print("[tar ] 解压 %s" % MASK_TAR)
        with tarfile.open(str(tar)) as t:
            t.extractall(str(WEIGHTS))
        print("   -> %s" % (out / "frozen_inference_graph.pb"))
    print("done.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
