﻿# -*- coding: utf-8 -*-
"""实验六 分割：路径 / 类别 / 超参配置。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WEIGHTS = ROOT / "weights"
IMAGES = ROOT / "images"
RESULTS = ROOT / "results"
FIGURES = RESULTS / "figures"
JSONS = RESULTS / "json"
LOGS = RESULTS / "logs"

# ---------------------------------------------------------------- 语义分割 FCN8s
PROTOTXT = WEIGHTS / "fcn8s-heavy-pascal.prototxt"
CAFFEMODEL = WEIGHTS / "fcn8s-heavy-pascal.caffemodel"
PASCAL_CLASSES = WEIGHTS / "pascal-classes.txt"
# FCN8s（VGG16）训练时用的 BGR 均值，单位 0~255
PASCAL_MEAN = (104.00698793, 116.66876762, 122.67891434)
# prototxt 里 input_dim 固定写死 500×500，输入必须按这个尺寸做 blob
FCN_SIZE = (500, 500)

# ---------------------------------------------------------------- 实例分割 Mask R-CNN
MASK_PB = WEIGHTS / "mask_rcnn_inception_v2_coco_2018_01_28" / "frozen_inference_graph.pb"
# TF OD API 的 frozen graph 不能直接喂给 OpenCV：必须先用 tools/build_mask_graph.py
# 生成文本图（pbtxt），再 readNetFromTensorflow(pb, pbtxt)。
MASK_PBTXT = WEIGHTS / "mask_rcnn.pbtxt"
COCO_CLASSES = WEIGHTS / "coco_classes.txt"
MASK_CONF = 0.5          # 检测置信度阈值
MASK_NMS = 0.3           # 额外补的一层同类 NMS（frozen graph 自带一次，但阈值偏松）

# VOC 的 21 类（顺序 = FCN8s 输出通道顺序，0 是背景）
VOC21 = ["background", "aeroplane", "bicycle", "bird", "boat", "bottle", "bus",
         "car", "cat", "chair", "cow", "diningtable", "dog", "horse",
         "motorbike", "person", "pottedplant", "sheep", "sofa", "train", "tvmonitor"]

# 演示用图像（文件名 -> 一句话内容，报告里直接引用）
DEMO_IMAGES = [
    ("voc_000302.jpg", "街景（车/人/道路/建筑）"),
    ("bus.jpg", "公交车 + 站台行人"),
    ("zidane.jpg", "两名球员（同类多实例）"),
    ("voc_004091.jpg", "十人合影 + 加长车"),
    ("voc_006043.jpg", "赛车特写 + 背景行人"),
    ("voc_000169.jpg", "展台跑车 + 路人"),
]
