# -*- coding: utf-8 -*-
"""环境自检：Python / OpenCV / DNN 后端 / 模型文件 / 中文字体。

用法：.venv\\Scripts\\python.exe src\\env_check.py
"""
import json
import platform
import sys

import cv2
import numpy as np

import common
import config


def main():
    info = {"python": sys.version.split()[0], "platform": platform.platform(),
            "cv2": cv2.__version__,
            "threads": cv2.getNumThreads(),
            "numpy": np.__version__,
            "has_readNetFromCaffe": hasattr(cv2.dnn, "readNetFromCaffe"),
            "has_readNetFromTensorflow": hasattr(cv2.dnn, "readNetFromTensorflow"),
            "models": {}}
    for key, p in {"prototxt": config.PROTOTXT, "caffemodel": config.CAFFEMODEL,
                   "pascal_classes": config.PASCAL_CLASSES, "mask_pb": config.MASK_PB,
                   "coco_classes": config.COCO_CLASSES}.items():
        info["models"][key] = str(p) if p.exists() else None
        if p.exists():
            info["models"][key + "_mb"] = round(p.stat().st_size / 2 ** 20, 2)

    print(json.dumps(info, ensure_ascii=False, indent=2))
    common.save_json(info, config.JSONS / "env_check.json")

    # 中文路径回归测试：这个目录就叫「实验六」
    img_path = config.IMAGES / config.DEMO_IMAGES[0][0]
    direct = cv2.imread(str(img_path))
    safe = common.imread(str(img_path))
    print("\n中文路径测试：cv2.imread -> %s，common.imread -> %s" % (
        None if direct is None else direct.shape,
        None if safe is None else safe.shape))
    info["chinese_path"] = {"cv2.imread": None if direct is None else list(direct.shape),
                            "common.imread": None if safe is None else list(safe.shape)}
    common.save_json(info, config.JSONS / "env_check.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
