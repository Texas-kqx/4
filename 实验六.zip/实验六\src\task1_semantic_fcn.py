# -*- coding: utf-8 -*-
"""任务一（语义分割）：FCN8s / OpenCV DNN 完整流程。

对应实验报告的三节：
    1. 理解模型输出   —— 加载 class / model / config，打印 score.shape
    2. 实现像素分类   —— seg_utils.get_class_map
    3. 分割结果可视化 —— generate_color_map / generate_mask / cv2.addWeighted 融合

用法：
    .venv\\Scripts\\python.exe src\\task1_semantic_fcn.py [--limit 6]
"""
import argparse
import sys
import time
from pathlib import Path

import cv2
import numpy as np

import common
import config
import seg_utils


def load_everything():
    """TODO 1：加载类别文件、模型文件、配置文件。"""
    classes = common.load_names(config.PASCAL_CLASSES)
    print("[names] %s → %d 类：%s" % (config.PASCAL_CLASSES.name, len(classes), classes))
    print("[model] prototxt  = %s" % config.PROTOTXT.name)
    print("[model] caffemodel = %s (%.1f MB)" % (
        config.CAFFEMODEL.name, config.CAFFEMODEL.stat().st_size / 2 ** 20))
    net = cv2.dnn.readNetFromCaffe(common.dnn_path(config.PROTOTXT),
                                   common.dnn_path(config.CAFFEMODEL))
    net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
    net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
    return net, classes


def inspect_output(net, image, classes):
    """第 1 节：理解模型输出尺寸与含义。"""
    print("\n=== 1. 理解模型输出 ===")
    print("原图尺寸 (H,W,C) = %s" % (image.shape,))
    t0 = time.perf_counter()
    blob = cv2.dnn.blobFromImage(image, 1.0, config.FCN_SIZE, config.PASCAL_MEAN,
                                 swapRB=False, crop=False)
    net.setInput(blob)
    score = net.forward()
    ms = (time.perf_counter() - t0) * 1000
    print("blob 尺寸 = %s   （N=1, C=3, H=500, W=500，与 prototxt 的 input_dim 一致）" % (blob.shape,))
    print("模型输出尺寸：", score.shape, " 前向耗时 %.1f ms" % ms)
    print("→ 第 0 维是 batch；第 1 维 21 = 20 个前景类 + 1 个背景类；第 2/3 维是特征图高宽。")
    print("→ 输出是未归一化的 logits（可正可负），不是概率；比较大小用 argmax 就够了。")
    print("→ 21 个通道按 pascal-classes.txt 的顺序排列，通道 0 = background。")
    s = np.squeeze(score)
    print("logits 范围 = [%.2f, %.2f]，均值 %.3f" % (s.min(), s.max(), s.mean()))
    print("各类别平均得分前 5：")
    means = s.reshape(s.shape[0], -1).mean(axis=1)
    for i in np.argsort(-means)[:5]:
        print("    %-12s %.3f" % (classes[i], means[i]))
    return score, ms


def run_one(net, classes, colors, name, desc, timer):
    path = config.IMAGES / name
    image = common.imread(str(path))
    if image is None:
        print("[skip] 读不到 %s" % path)
        return None
    t0 = time.perf_counter()
    blob = cv2.dnn.blobFromImage(image, 1.0, config.FCN_SIZE, config.PASCAL_MEAN,
                                 swapRB=False, crop=False)
    t1 = time.perf_counter()
    net.setInput(blob)
    score = net.forward()
    t2 = time.perf_counter()
    # 21 通道 logits 双线性上采样回原图分辨率，再逐像素 argmax
    prob = np.squeeze(score, axis=0)
    h, w = image.shape[:2]
    prob = cv2.resize(prob.transpose(1, 2, 0), (w, h),
                      interpolation=cv2.INTER_LINEAR).transpose(2, 0, 1)
    class_map = seg_utils.get_class_map(np.ascontiguousarray(prob)[None, ...])
    mask = seg_utils.generate_mask(class_map, colors)
    fused = seg_utils.blend_mask(image, mask, 0.4, 0.6)      # 报告里的 addWeighted
    fused_fg = seg_utils.blend_foreground(image, mask, class_map, 0.5)
    t3 = time.perf_counter()
    timer.add("preprocess", (t1 - t0) * 1000)
    timer.add("forward", (t2 - t1) * 1000)
    timer.add("postprocess", (t3 - t2) * 1000)

    stats = seg_utils.class_area_stats(class_map, classes)
    tag = Path(name).stem
    common.imwrite(config.FIGURES / ("T1_%s_mask.png" % tag), mask)
    common.imwrite(config.FIGURES / ("T1_%s_fused.png" % tag), fused_fg)
    common.panel_figure(
        config.FIGURES / ("T1_%s_pipeline.png" % tag),
        [image, mask, fused, fused_fg],
        ["原图（%s）" % desc, "generate_mask 彩色掩码",
         "cv2.addWeighted(图0.4/掩码0.6)", "只融合前景（改进版）"],
        cols=2, figsize=(9.6, 5.4))

    print("\n[%s] %s  score=%s → class_map=%s  前景占比 %.1f%%  前向 %.0f ms" % (
        name, desc, tuple(np.squeeze(score).shape), class_map.shape,
        100.0 * np.count_nonzero(class_map) / class_map.size, (t2 - t1) * 1000))
    for r in stats[:5]:
        print("    %-12s %6.2f%%" % (r["name"], r["ratio"]))
    return {"image": name, "desc": desc, "shape": list(image.shape),
            "score_shape": list(score.shape), "class_map_shape": list(class_map.shape),
            "num_classes_found": len(stats),
            "ms": {"preprocess": round((t1 - t0) * 1000, 2),
                   "forward": round((t2 - t1) * 1000, 2),
                   "postprocess": round((t3 - t2) * 1000, 2)},
            "stats": stats, "_image": image, "_mask": mask, "_fused": fused_fg,
            "_class_map": class_map}


def figure_channels(score, image, classes):
    """把 21 个通道里“响应最大”的 4 个类画成热力图，直观看到“每个像素 21 个得分”。"""
    s = np.squeeze(score)                              # [21,h,w]
    means = s.reshape(s.shape[0], -1).mean(axis=1)
    top = list(np.argsort(-means)[:4])
    panels, titles = [image], ["原图"]
    for i in top:
        panels.append(cv2.applyColorMap(
            cv2.normalize(s[i], None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8),
            cv2.COLORMAP_JET))
        titles.append("通道 %d：%s（均值 %.2f）" % (i, classes[i], means[i]))
    common.panel_figure(config.FIGURES / "T1_score_channels.png", panels, titles, cols=5,
                        figsize=(18, 3.8),
                        title="FCN8s 输出 21 通道中响应最强的 4 类（JET：越红得分越高）")


def figure_compare_mean(seg_a, seg_b, names):
    """对照实验：减 VOC 均值 vs 不减，比较像素分类结果的一致率。"""
    print("\n=== 对照实验：预处理是否减 VOC 均值 (104.0,116.7,122.7) ===")
    rows, panels, titles = [], [], []
    for name in names:
        img = common.imread(str(config.IMAGES / name))
        a = seg_a.predict(img)["class_map"]
        b = seg_b.predict(img)["class_map"]
        agree = float((a == b).mean())
        fa = 100.0 * np.count_nonzero(a) / a.size
        fb = 100.0 * np.count_nonzero(b) / b.size
        rows.append({"image": name, "agree": round(agree, 4),
                     "fg_with_mean": round(fa, 2), "fg_without_mean": round(fb, 2),
                     "classes_with_mean": int(len(np.unique(a))),
                     "classes_without_mean": int(len(np.unique(b)))})
        print("  %-16s 一致率 %.2f%%  前景占比：减均值 %.1f%% / 不减 %.1f%%" % (
            name, agree * 100, fa, fb))
        panels += [a, b]
        titles += ["减均值：%s" % name, "不减均值：%s" % name]
    common.panel_figure(config.FIGURES / "T1_mean_compare.png", panels, titles, cols=2,
                        figsize=(8.4, 2.5 * len(names)),
                        title="预处理是否减均值：像素分类结果对比")
    return rows


def figure_palette(colors, classes):
    """调色板图例：类别 ID → 颜色，方便对照掩码里的每一块颜色。"""
    import matplotlib.pyplot as plt
    common.setup_plot()
    fig, ax = plt.subplots(figsize=(5.6, 5.0))
    for i, (c, name) in enumerate(zip(colors, classes)):
        ax.add_patch(plt.Rectangle((0, i), 1, 1, color=(c[2] / 255.0, c[1] / 255.0, c[0] / 255.0)))
        ax.text(1.15, i + 0.5, "%2d   %s" % (i, name), va="center", fontsize=8.5)
    ax.set_xlim(0, 2.6)
    ax.set_ylim(0, len(classes))
    ax.invert_yaxis()
    ax.axis("off")
    ax.set_title("generate_color_map(21) 的调色板", fontsize=11)
    fig.savefig(str(config.FIGURES / "T1_palette.png"), dpi=110)
    plt.close(fig)
    print("[fig ] %s" % (config.FIGURES / "T1_palette.png"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()
    for d in (config.FIGURES, config.JSONS, config.LOGS):
        d.mkdir(parents=True, exist_ok=True)

    with common.tee("task1_semantic_fcn"):
        net, classes = load_everything()
        colors = seg_utils.generate_color_map(len(classes))
        print("[colors] generate_color_map(%d) → %s（背景 %s 为黑色）" % (
            len(classes), colors.shape, tuple(colors[0])))
        figure_palette(colors, classes)

        first = common.imread(str(config.IMAGES / config.DEMO_IMAGES[0][0]))
        score, ms = inspect_output(net, first, classes)
        figure_channels(score, first, classes)

        timer = common.Timer()
        results = []
        demo = config.DEMO_IMAGES[:args.limit] if args.limit else config.DEMO_IMAGES
        for name, desc in demo:
            r = run_one(net, classes, colors, name, desc, timer)
            if r:
                results.append(r)

        # 全量结果拼图（每张图的最终融合结果，3 列）
        panels = [r["_fused"] for r in results]
        titles = [r["image"] for r in results]
        common.panel_figure(config.FIGURES / "T1_all_results.png", panels, titles, cols=3,
                            figsize=(15, 3.4 * int(np.ceil(len(results) / 3.0))),
                            title="FCN8s 语义分割：6 张演示图的前景融合结果")

        for r in results:
            r.pop("_class_map", None)
            r.pop("_image", None)
            r.pop("_mask", None)
            r.pop("_fused", None)

        # 每张图的类占比堆叠柱状图
        import matplotlib.pyplot as plt
        common.setup_plot()
        names = [r["image"] for r in results]
        top_ids = [0, 7, 15, 6, 13, 2, 11, 19]          # 背景/车/人/公交/马/自行车/餐桌/火车
        fig, ax = plt.subplots(figsize=(9.4, 4.2))
        bottom = np.zeros(len(results))
        for cid in top_ids:
            vals = np.array([next((s["ratio"] for s in r["stats"] if s["id"] == cid), 0.0)
                             for r in results])
            if vals.sum() == 0:
                continue
            ax.bar(names, vals, bottom=bottom, label=classes[cid])
            bottom += vals
        ax.set_ylabel("像素占比 (%)")
        ax.set_title("FCN8s 在演示图上的类别像素分布")
        ax.legend(ncol=4, fontsize=8)
        plt.xticks(rotation=15, fontsize=8)
        fig.savefig(str(config.FIGURES / "T1_class_ratio.png"), dpi=110)
        plt.close(fig)
        print("[fig ] %s" % (config.FIGURES / "T1_class_ratio.png"))

        seg_a = seg_utils.FCNSegmenter(config.PROTOTXT, config.CAFFEMODEL, config.FCN_SIZE, True)
        seg_b = seg_utils.FCNSegmenter(config.PROTOTXT, config.CAFFEMODEL, config.FCN_SIZE, False)
        mean_rows = figure_compare_mean(seg_a, seg_b, [n for n, _ in demo[:4]])

        # 反例：输入尺寸改成 320×320 时 prototxt 的 Crop 层会怎样
        print("\n=== 附：输入尺寸不是 500×500 时会发生什么 ===")
        try:
            net2 = cv2.dnn.readNetFromCaffe(common.dnn_path(config.PROTOTXT),
                                            common.dnn_path(config.CAFFEMODEL))
            blob = cv2.dnn.blobFromImage(first, 1.0, (320, 320), config.PASCAL_MEAN, crop=False)
            net2.setInput(blob)
            s2 = net2.forward()
            print("  320×320 输入 → 输出 %s（Crop 层按输入形状裁，能跑通）" % (s2.shape,))
            size_note = {"input": 320, "output_shape": list(s2.shape), "ok": True}
        except Exception as e:  # noqa: BLE001
            print("  320×320 输入 → 失败：%s: %s" % (type(e).__name__, e))
            size_note = {"input": 320, "error": str(e), "ok": False}

        summary = {"model": {"prototxt": config.PROTOTXT.name,
                             "caffemodel": config.CAFFEMODEL.name,
                             "caffemodel_mb": round(config.CAFFEMODEL.stat().st_size / 2 ** 20, 1),
                             "classes": len(classes), "input_size": list(config.FCN_SIZE)},
                   "first_output_shape": list(score.shape),
                   "forward_ms_first": round(ms, 2),
                   "timing": timer.summary(),
                   "images": results,
                   "mean_compare": mean_rows,
                   "size_320": size_note,
                   "palette": {"0": [int(x) for x in colors[0]],
                               "7": [int(x) for x in colors[7]]}}
        common.save_json(summary, config.JSONS / "task1_semantic_fcn.json")

        print("\n%-18s %9s %9s %10s %8s" % ("image", "pre(ms)", "forward", "post(ms)", "前景%"))
        for r in results:
            fg = 100 - next((s["ratio"] for s in r["stats"] if s["id"] == 0), 0.0)
            print("%-18s %9.1f %9.1f %10.1f %8.1f" % (
                r["image"], r["ms"]["preprocess"], r["ms"]["forward"],
                r["ms"]["postprocess"], fg))
        print("\n平均：%s" % timer.summary())
    return 0


if __name__ == "__main__":
    sys.exit(main())
