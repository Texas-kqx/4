# -*- coding: utf-8 -*-
"""实验六 公共工具：中文路径安全 IO、cv2.dnn 的 ASCII 路径、日志、画图、计时。"""
import hashlib
import json
import os
import shutil
import sys
import tempfile
import time
from contextlib import contextmanager
from pathlib import Path

import cv2
import numpy as np

import config


# ------------------------------------------------------------------ 中文路径安全 IO
# 实测：本实验目录叫「实验六」，cv2.imread / cv2.imwrite 直接返回 None / False
# （日志里是 can't open/read file: check file path/integrity），
# 而 np.fromfile / ndarray.tofile 走 Python 的宽字符 API，完全正常。
def imread(path, flags=cv2.IMREAD_COLOR):
    p = str(path)
    if not os.path.exists(p):
        return None
    buf = np.fromfile(p, dtype=np.uint8)
    if buf.size == 0:
        return None
    return cv2.imdecode(buf, flags)


def imwrite(path, img, params=None):
    path = str(path)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    ext = os.path.splitext(path)[1].lower() or ".png"
    ok, buf = cv2.imencode(ext, img, params or [])
    if not ok:
        return False
    buf.tofile(path)
    return True


# ------------------------------------------------------------------ cv2.dnn 的 ASCII 路径
# cv2.dnn.readNetFromCaffe / readNetFromTensorflow 内部同样用窄字符 fopen，
# 路径含中文时直接抛错或静默失败。把模型复制到纯 ASCII 临时目录再加载。
_ASCII_CACHE = Path(tempfile.gettempdir()) / "exp6_dnn_ascii"


def dnn_path(p):
    p = Path(p)
    try:
        str(p).encode("ascii")
        return str(p)
    except UnicodeEncodeError:
        pass
    _ASCII_CACHE.mkdir(parents=True, exist_ok=True)
    dst = _ASCII_CACHE / (hashlib.md5(str(p).encode("utf-8")).hexdigest()[:8] + "_" + p.name)
    if not dst.exists() or dst.stat().st_size != p.stat().st_size:
        print("[dnn] 中文路径 → ASCII 副本：%s → %s" % (p.name, dst), flush=True)
        shutil.copy2(str(p), str(dst))
    return str(dst)


# ------------------------------------------------------------------ 日志
class _Tee:
    def __init__(self, path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.f = open(str(path), "w", encoding="utf-8")

    def write(self, s):
        sys.__stdout__.write(s)
        sys.__stdout__.flush()
        self.f.write(s)

    def flush(self):
        sys.__stdout__.flush()
        self.f.flush()


@contextmanager
def tee(name):
    """把 stdout 同时写进 results/logs/<name>.log（UTF-8，避免 GBK 乱码）。"""
    path = config.LOGS / (name + ".log")
    t = _Tee(path)
    old = sys.stdout
    sys.stdout = t
    t0 = time.time()
    try:
        print("# %s  start %s  python %s  cv2 %s" % (
            name, time.strftime("%Y-%m-%d %H:%M:%S"), sys.version.split()[0], cv2.__version__))
        yield
    finally:
        print("# %s  done in %.1f s" % (name, time.time() - t0))
        sys.stdout = old
        t.f.close()


def save_json(obj, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    print("[json] %s" % path)


def load_names(path):
    return [l.strip() for l in Path(path).read_text(encoding="utf-8").splitlines() if l.strip()]


# ------------------------------------------------------------------ 绘图
def setup_plot():
    import matplotlib
    matplotlib.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei",
                                              "Noto Sans CJK SC", "DejaVu Sans"]
    matplotlib.rcParams["axes.unicode_minus"] = False
    matplotlib.rcParams["figure.dpi"] = 110
    matplotlib.rcParams["savefig.bbox"] = "tight"


def panel_figure(path, panels, titles, cols=None, figsize=None, title=None, cmaps=None):
    """把若干 BGR / 灰度 / 二值图排成一张对比图并存盘。

    panels: list[np.ndarray]，BGR 三通道或单通道；titles: list[str]
    """
    import matplotlib.pyplot as plt
    setup_plot()
    n = len(panels)
    cols = cols or n
    rows = int(np.ceil(n / cols))
    if figsize is None:
        figsize = (3.6 * cols, 2.9 * rows + (0.4 if title else 0))
    fig, axes = plt.subplots(rows, cols, figsize=figsize, squeeze=False)
    for i in range(rows * cols):
        ax = axes[i // cols][i % cols]
        ax.axis("off")
        if i >= n:
            continue
        im = panels[i]
        cmap = (cmaps[i] if cmaps else None) or ("gray" if im.ndim == 2 else None)
        if im.ndim == 3:
            ax.imshow(cv2.cvtColor(im, cv2.COLOR_BGR2RGB))
        else:
            ax.imshow(im, cmap=cmap, vmin=0, vmax=(1 if im.dtype.kind == "f" else None))
        ax.set_title(titles[i], fontsize=10)
    if title:
        fig.suptitle(title, fontsize=12)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(str(path), dpi=110)
    plt.close(fig)
    print("[fig ] %s" % path)


# ------------------------------------------------------------------ 计时
class Timer:
    def __init__(self):
        self.stats = {}

    def add(self, key, ms):
        self.stats.setdefault(key, []).append(ms)

    @contextmanager
    def __call__(self, key):
        t0 = time.perf_counter()
        try:
            yield
        finally:
            self.add(key, (time.perf_counter() - t0) * 1000)

    def summary(self):
        out = {}
        for k, v in self.stats.items():
            a = np.asarray(v, np.float32)
            out[k] = {"n": int(a.size), "mean_ms": round(float(a.mean()), 2),
                      "median_ms": round(float(np.median(a)), 2),
                      "p95_ms": round(float(np.percentile(a, 95)), 2)}
        return out
