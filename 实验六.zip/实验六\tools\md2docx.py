# -*- coding: utf-8 -*-
"""把 实验报告.md 转成 实验报告.docx（够用的 markdown 子集：标题/段落/列表/表格/图片/代码块/引用）。

用法：.venv\\Scripts\\python.exe tools\\md2docx.py [源.md] [目标.docx]
依赖：python-docx
"""
import re
import sys
import tempfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ROOT = Path(__file__).resolve().parents[1]
CN_FONT = "微软雅黑"
MONO_FONT = "Consolas"


def set_cn_font(run, name=CN_FONT):
    run.font.name = name
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    rfonts.set(qn("w:eastAsia"), name)


def add_rich_text(par, text, base_size=None, bold_all=False):
    """处理 **粗体**、`代码`、*斜体*。"""
    tokens = re.split(r"(\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*)", text)
    for tok in tokens:
        if not tok:
            continue
        if tok.startswith("**") and tok.endswith("**"):
            r = par.add_run(tok[2:-2])
            r.bold = True
        elif tok.startswith("`") and tok.endswith("`"):
            r = par.add_run(tok[1:-1])
            r.font.name = MONO_FONT
            r.font.size = Pt((base_size or 10.5) - 1)
            r.font.color.rgb = RGBColor(0xA0, 0x30, 0x30)
        elif tok.startswith("*") and tok.endswith("*") and len(tok) > 2:
            r = par.add_run(tok[1:-1])
            r.italic = True
        else:
            r = par.add_run(tok)
            r.bold = bold_all
        if base_size and not (tok.startswith("`")):
            r.font.size = Pt(base_size)
        set_cn_font(r)


def add_table(doc, rows):
    ncol = len(rows[0])
    t = doc.add_table(rows=0, cols=ncol)
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for ri, row in enumerate(rows):
        cells = t.add_row().cells
        for ci in range(ncol):
            txt = row[ci] if ci < len(row) else ""
            p = cells[ci].paragraphs[0]
            add_rich_text(p, txt, base_size=9, bold_all=(ri == 0))
            p.paragraph_format.space_before = Pt(1)
            p.paragraph_format.space_after = Pt(1)
            if ri == 0:
                shd = OxmlElement("w:shd")
                shd.set(qn("w:fill"), "EAF1F8")
                cells[ci]._tc.get_or_add_tcPr().append(shd)
    return t


def add_image(doc, path, width_cm=15.5):
    p = Path(path)
    if not p.exists():
        par = doc.add_paragraph()
        r = par.add_run(f"[缺图：{path}]")
        r.font.color.rgb = RGBColor(0xC0, 0x00, 0x00)
        return
    # 原始 PNG 动辄 2 MB，13 张图塞进 docx 会到 14 MB。这里按宽度 1600 缩一次、转 JPEG，
    # 版面不变但文件小一个数量级。
    try:
        from PIL import Image
        im = Image.open(str(p))
        if im.width > 1600 or p.stat().st_size > 700 * 1024:
            if im.mode != "RGB":
                im = im.convert("RGB")
            scale = min(1.0, 1600 / im.width)
            im = im.resize((int(im.width * scale), int(im.height * scale)), Image.LANCZOS)
            tmp = Path(tempfile.gettempdir()) / (p.stem + "_docx.jpg")
            im.save(str(tmp), quality=88, optimize=True)
            p = tmp
    except Exception:  # noqa: BLE001  Pillow 不在就原图发
        pass
    doc.add_picture(str(p), width=Cm(width_cm))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER


def add_code(doc, lines):
    for ln in lines:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Cm(0.6)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = 1.0
        r = p.add_run(ln if ln else " ")
        r.font.name = MONO_FONT
        r.font.size = Pt(9)
        r.font.color.rgb = RGBColor(0x33, 0x33, 0x33)


def parse_table_block(lines):
    rows = []
    for ln in lines:
        s = ln.strip().strip("|")
        cells = [c.strip() for c in s.split("|")]
        if all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c):
            continue
        rows.append(cells)
    return rows


def main():
    src = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "实验报告.md"
    dst = Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / "实验报告.docx"
    lines = src.read_text(encoding="utf-8").splitlines()

    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(2.4)
    sec.top_margin = sec.bottom_margin = Cm(2.2)
    st = doc.styles["Normal"]
    st.font.name = CN_FONT
    st.font.size = Pt(10.5)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), CN_FONT)

    i = 0
    n = len(lines)
    while i < n:
        ln = lines[i]
        s = ln.strip()

        if not s:
            i += 1
            continue

        # 代码块
        if s.startswith("```"):
            i += 1
            buf = []
            while i < n and not lines[i].strip().startswith("```"):
                buf.append(lines[i])
                i += 1
            i += 1
            add_code(doc, buf)
            continue

        # 表格
        if s.startswith("|") and i + 1 < n and re.match(r"^\|[\s:|-]+\|$", lines[i + 1].strip()):
            buf = []
            while i < n and lines[i].strip().startswith("|"):
                buf.append(lines[i])
                i += 1
            add_table(doc, parse_table_block(buf))
            doc.add_paragraph()
            continue

        # 图片
        m = re.match(r"^!\[(.*?)\]\((.*?)\)$", s)
        if m:
            add_image(doc, str((src.parent / m.group(2)).resolve()) if not Path(m.group(2)).is_absolute()
                      else m.group(2))
            cap = doc.add_paragraph()
            cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = cap.add_run(m.group(1))
            r.font.size = Pt(9)
            r.italic = True
            set_cn_font(r)
            i += 1
            continue

        # 分隔线
        if re.fullmatch(r"-{3,}|\*{3,}", s):
            p = doc.add_paragraph()
            pPr = p._p.get_or_add_pPr()
            pbdr = OxmlElement("w:pBdr")
            bottom = OxmlElement("w:bottom")
            bottom.set(qn("w:val"), "single")
            bottom.set(qn("w:sz"), "6")
            bottom.set(qn("w:color"), "BBBBBB")
            pbdr.append(bottom)
            pPr.append(pbdr)
            i += 1
            continue

        # 标题
        m = re.match(r"^(#{1,4})\s+(.*)$", s)
        if m:
            level = len(m.group(1))
            text = m.group(2).strip()
            h = doc.add_heading(level=min(level, 4) - 0 if level > 1 else 0)
            r = h.add_run(text)
            set_cn_font(r)
            r.font.size = Pt({1: 20, 2: 15, 3: 12.5, 4: 11}.get(level, 11))
            r.font.color.rgb = RGBColor(0x1F, 0x3B, 0x57)
            r.bold = True
            i += 1
            continue

        # 引用
        if s.startswith(">"):
            buf = []
            while i < n and lines[i].strip().startswith(">"):
                buf.append(lines[i].strip().lstrip(">").strip())
                i += 1
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.5)
            add_rich_text(p, " ".join([b for b in buf if b]), base_size=9.5)
            for r in p.runs:
                r.font.color.rgb = RGBColor(0x55, 0x55, 0x55)
            i += 1
            continue

        # 列表
        m = re.match(r"^([-*+])\s+(.*)$", s)
        if m:
            p = doc.add_paragraph(style="List Bullet")
            add_rich_text(p, m.group(2), base_size=10.5)
            i += 1
            continue
        m = re.match(r"^(\d+)[.)]\s+(.*)$", s)
        if m:
            # 有序列表：不用 List Number 样式（Word 会跨节连续编号，出现 21. 22. 这种），
            # 直接把 md 里的序号写成文本，保证从 1 开始。
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.75)
            p.paragraph_format.first_line_indent = Cm(-0.45)
            p.paragraph_format.space_after = Pt(3)
            add_rich_text(p, f"{m.group(1)}. {m.group(2)}", base_size=10.5)
            i += 1
            continue

        # 普通段落（合并连续行）
        buf = [s]
        i += 1
        while i < n and lines[i].strip() and not re.match(
                r"^(#{1,4}\s|\||```|>|!\[|[-*+]\s|\d+[.)]\s|-{3,})", lines[i].strip()):
            buf.append(lines[i].strip())
            i += 1
        p = doc.add_paragraph()
        p.paragraph_format.first_line_indent = Cm(0)
        p.paragraph_format.space_after = Pt(6)
        add_rich_text(p, " ".join(buf), base_size=10.5)

    doc.save(str(dst))
    print(f"wrote {dst}")


if __name__ == "__main__":
    main()
