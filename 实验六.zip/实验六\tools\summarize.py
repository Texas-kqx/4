# -*- coding: utf-8 -*-
"""把 results/json 里的实测数字汇总成 results/summary_tables.md（报告里的表都由它生成）。

用法：.venv\\Scripts\\python.exe tools\\summarize.py
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
J = ROOT / "results" / "json"
OUT = ROOT / "results" / "summary_tables.md"


def load(name):
    p = J / name
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


def main():
    t1, t2, t3, env = (load("task1_semantic_fcn.json"), load("task2_instance_maskrcnn.json"),
                       load("task3_compare.json"), load("env_check.json"))
    L = ["# 实验六 结果汇总（由 tools/summarize.py 从 results/json 生成）", ""]

    if env:
        L += ["## 0. 环境", ""]
        L += ["| 项目 | 值 |", "|---|---|"]
        L += ["| Python | %s |" % env.get("python"),
              "| OpenCV | %s |" % env.get("cv2"),
              "| NumPy | %s |" % env.get("numpy"),
              "| CPU 线程 | %s |" % env.get("threads")]
        cp = env.get("chinese_path", {})
        L += ["| 中文路径 cv2.imread | `%s` |" % cp.get("cv2.imread"),
              "| 中文路径 common.imread | `%s` |" % cp.get("common.imread"), ""]

    if t1:
        L += ["## 1. 语义分割 FCN8s", "",
              "- 模型：%s + %s（%.1f MB），输入 %s，输出 %s" % (
                  t1["model"]["prototxt"], t1["model"]["caffemodel"],
                  t1["model"]["caffemodel_mb"], t1["model"]["input_size"],
                  t1["first_output_shape"]),
              "- 平均耗时：预处理 %.2f ms / 前向 %.2f ms / 后处理 %.2f ms" % (
                  t1["timing"]["preprocess"]["mean_ms"], t1["timing"]["forward"]["mean_ms"],
                  t1["timing"]["postprocess"]["mean_ms"]), "",
              "| 图像 | 尺寸(H×W) | 前景% | top1 | top2 | top3 | 前向(ms) |",
              "|---|---|---|---|---|---|---|"]
        for r in t1["images"]:
            s = [x for x in r["stats"] if x["id"] != 0]      # 只列前景类
            bg = next((x["ratio"] for x in r["stats"] if x["id"] == 0), 0.0)
            get = lambda k: (s[k]["name"] + " " + str(s[k]["ratio"])) if k < len(s) else "—"
            L.append("| %s | %d×%d | %.1f | %s | %s | %s | %.0f |" % (
                r["image"], r["shape"][0], r["shape"][1],
                100 - bg,
                get(0), get(1), get(2), r["ms"]["forward"]))
        L += ["", "### 对照：是否减 VOC 均值", "",
              "| 图像 | 像素一致率 | 前景%(减均值) | 前景%(不减) |", "|---|---|---|---|"]
        for r in t1.get("mean_compare", []):
            L.append("| %s | %.2f%% | %.2f | %.2f |" % (
                r["image"], r["agree"] * 100, r["fg_with_mean"], r["fg_without_mean"]))
        L += ["", "输入 320×320 测试：%s" % t1.get("size_320"), ""]

    if t2:
        L += ["## 2. 实例分割 Mask R-CNN", "",
              "- 模型：%s（%.1f MB），conf=%.2f，NMS=%.2f" % (
                  Path(t2["model"]["pb"]).parent.name, t2["model"]["pb_mb"],
                  t2["model"]["conf_thr"], t2["model"]["nms_iou"]),
              "- 输出：detection_out_final %s，detection_masks %s" % (
                  t2["output"]["detection_out_final"], t2["output"]["detection_masks"]),
              "- 平均耗时：预处理 %.2f ms / 前向 %.2f ms / 后处理 %.2f ms" % (
                  t2["timing"]["preprocess"]["mean_ms"], t2["timing"]["forward"]["mean_ms"],
                  t2["timing"]["postprocess"]["mean_ms"]), "",
              "| 图像 | 候选 | NMS后 | 类别分布 | 前向(ms) | 后处理(ms) |",
              "|---|---|---|---|---|---|"]
        for r in t2["images"]:
            cnt = ", ".join("%s×%d" % (k, v) for k, v in r["class_count"].items()) or "—"
            L.append("| %s | %d | %d | %s | %.0f | %.1f |" % (
                r["image"], r["num_raw"], r["num_instances"], cnt,
                r["ms"]["forward"], r["ms"]["postprocess"]))
        L += ["", "合计：%s" % t2["class_total"], ""]

    if t3:
        L += ["## 3. 语义 vs 实例（同一张图）", "",
              "- 跨模型 IoU 平均 %.3f / 中位数 %.3f（%d 组）" % (
                  t3["mean_iou"], t3["median_iou"], len(t3["pairs"])), "",
              "| 图像 | FCN前景% | 实例数 | 实例前景% | person实例 | FCN person连通域 | person IoU | 其他类 IoU |",
              "|---|---|---|---|---|---|---|---|"]
        for r in t3["images"]:
            pc = r["per_class"]
            p = pc.get("person", {}).get("iou", float("nan"))
            other = ", ".join("%s %.3f" % (k, v["iou"]) for k, v in pc.items() if k != "person") or "—"
            L.append("| %s | %.1f | %d | %.1f | %d | %d | %.3f | %s |" % (
                r["image"], r["fcn_fg_ratio"], r["inst_count"], r["inst_fg_ratio"],
                r["person_instances"], r["fcn_person_components"], p, other))
        L.append("")

    OUT.write_text("\n".join(L), encoding="utf-8")
    print("wrote %s (%d lines)" % (OUT, len(L)))


if __name__ == "__main__":
    main()
