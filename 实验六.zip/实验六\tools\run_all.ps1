# 实验六 一键运行（Windows PowerShell）
#   powershell -ExecutionPolicy Bypass -File tools\run_all.ps1
# 说明：模型需先用 tools\download_models.py 下载（约 700 MB）。
$ErrorActionPreference = "Stop"
$env:PYTHONIOENCODING = "utf-8"
$env:PYTHONUTF8 = "1"

$root = Split-Path -Parent $PSScriptRoot
$py = "D:\deep seek\.venv\Scripts\python.exe"
if (-not (Test-Path $py)) { $py = "python" }

Push-Location $root
try {
    Write-Host "== env_check ==" -ForegroundColor Cyan
    & $py src\env_check.py

    Write-Host "== task1 语义分割 FCN8s ==" -ForegroundColor Cyan
    & $py src\task1_semantic_fcn.py

    Write-Host "== task2 实例分割 Mask R-CNN ==" -ForegroundColor Cyan
    & $py src\task2_instance_maskrcnn.py

    Write-Host "== task3 语义 vs 实例对比 ==" -ForegroundColor Cyan
    & $py src\task3_compare.py

    Write-Host "== md -> docx ==" -ForegroundColor Cyan
    & $py tools\md2docx.py 实验报告.md 实验报告.docx
}
finally {
    Pop-Location
}
Write-Host "全部完成：results\figures / results\json / 实验报告.docx" -ForegroundColor Green
