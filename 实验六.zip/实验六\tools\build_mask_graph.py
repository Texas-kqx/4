# -*- coding: utf-8 -*-
"""把 TF Object Detection API 的 frozen graph 转成 OpenCV 需要的文本图（pbtxt）。

为什么必须要这一步：
    cv2.dnn.readNetFromTensorflow(pb) 直接读 mask_rcnn 的 frozen graph 会挂在
    graph_simplifier.cpp 的 nodeIds.find(inpName) 断言上（TF OD API 的后处理子图里
    有 OpenCV 不认识的形状/控制流节点）。OpenCV 官方做法是先跑
    samples/dnn/tf_text_graph_mask_rcnn.py，把图裁剪、重写成 OpenCV 支持的算子集合，
    再 readNetFromTensorflow(pb, pbtxt)。

本脚本做的事：
    1) 把 pb 与 pbtxt 都放到纯 ASCII 临时目录（OpenCV 的 fopen 不认中文路径）；
    2) 调用同目录下的 tf_text_graph_mask_rcnn.py 生成文本图；
    3) 把结果拷回 weights/mask_rcnn.pbtxt。

依赖：numpy + opencv（不需要 tensorflow，脚本优先走 cv2.dnn.writeTextGraph 分支）。

用法：
    .venv\\Scripts\\python.exe tools\\build_mask_graph.py
"""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PB = ROOT / "weights" / "mask_rcnn_inception_v2_coco_2018_01_28" / "frozen_inference_graph.pb"
CONFIG = ROOT / "weights" / "mask_rcnn_inception_v2_coco_2018_01_28" / "pipeline.config"
OUT = ROOT / "weights" / "mask_rcnn.pbtxt"


def main():
    if not PB.exists():
        print("缺少 %s，先跑 tools\\download_models.py" % PB)
        return 1
    if OUT.exists():
        print("[skip] %s 已存在 (%.1f KB)" % (OUT, OUT.stat().st_size / 1024))
        return 0

    tmp = Path(tempfile.gettempdir()) / "exp6_dnn_ascii"
    tmp.mkdir(parents=True, exist_ok=True)
    pb_ascii = tmp / "mask_rcnn_frozen.pb"
    if not pb_ascii.exists() or pb_ascii.stat().st_size != PB.stat().st_size:
        print("[copy] pb → %s" % pb_ascii)
        shutil.copy2(str(PB), str(pb_ascii))
    out_ascii = tmp / "mask_rcnn.pbtxt"

    cmd = [sys.executable, str(ROOT / "tools" / "tf_text_graph_mask_rcnn.py"),
           "--input", str(pb_ascii), "--output", str(out_ascii), "--config", str(CONFIG)]
    print("[run ] %s" % " ".join(cmd))
    r = subprocess.run(cmd, cwd=str(ROOT / "tools"))
    if r.returncode != 0 or not out_ascii.exists():
        print("生成失败（returncode=%s）" % r.returncode)
        return 1
    shutil.copy2(str(out_ascii), str(OUT))
    print("[ok  ] %s (%.1f KB)" % (OUT, OUT.stat().st_size / 1024))
    return 0


if __name__ == "__main__":
    sys.exit(main())
