# 实验六 结果汇总（由 tools/summarize.py 从 results/json 生成）

## 0. 环境

| 项目 | 值 |
|---|---|
| Python | 3.12.14 |
| OpenCV | 4.10.0 |
| NumPy | 2.3.5 |
| CPU 线程 | 32 |
| 中文路径 cv2.imread | `None` |
| 中文路径 common.imread | `[375, 500, 3]` |

## 1. 语义分割 FCN8s

- 模型：fcn8s-heavy-pascal.prototxt + fcn8s-heavy-pascal.caffemodel（513.0 MB），输入 [500, 500]，输出 [1, 21, 500, 500]
- 平均耗时：预处理 2.97 ms / 前向 773.84 ms / 后处理 97.15 ms

| 图像 | 尺寸(H×W) | 前景% | top1 | top2 | top3 | 前向(ms) |
|---|---|---|---|---|---|---|
| voc_000302.jpg | 375×500 | 18.6 | car 15.501 | person 2.974 | bird 0.069 | 724 |
| bus.jpg | 1080×810 | 40.2 | bus 28.726 | person 11.462 | car 0.056 | 774 |
| zidane.jpg | 720×1280 | 43.3 | person 43.306 | — | — | 724 |
| voc_004091.jpg | 375×500 | 38.8 | person 26.614 | car 11.733 | train 0.451 | 835 |
| voc_006043.jpg | 375×500 | 51.8 | car 37.164 | boat 12.796 | motorbike 1.169 | 813 |
| voc_000169.jpg | 333×500 | 58.1 | car 29.311 | train 25.856 | bus 2.556 | 772 |

### 对照：是否减 VOC 均值

| 图像 | 像素一致率 | 前景%(减均值) | 前景%(不减) |
|---|---|---|---|
| voc_000302.jpg | 98.26% | 18.55 | 18.18 |
| bus.jpg | 96.57% | 40.25 | 40.58 |
| zidane.jpg | 85.31% | 43.31 | 29.88 |
| voc_004091.jpg | 89.94% | 38.80 | 37.55 |

输入 320×320 测试：{'input': 320, 'output_shape': [1, 21, 320, 320], 'ok': True}

## 2. 实例分割 Mask R-CNN

- 模型：mask_rcnn_inception_v2_coco_2018_01_28（64.0 MB），conf=0.50，NMS=0.30
- 输出：detection_out_final [1, 1, 100, 7]，detection_masks [100, 90, 15, 15]
- 平均耗时：预处理 5.78 ms / 前向 1756.22 ms / 后处理 6.80 ms

| 图像 | 候选 | NMS后 | 类别分布 | 前向(ms) | 后处理(ms) |
|---|---|---|---|---|---|
| voc_000302.jpg | 8 | 6 | car×4, person×1, motorcycle×1 | 1534 | 4.2 |
| bus.jpg | 6 | 5 | person×4, bus×1 | 1982 | 12.9 |
| zidane.jpg | 3 | 2 | person×2 | 2262 | 11.2 |
| voc_004091.jpg | 7 | 7 | person×7 | 1683 | 5.2 |
| voc_006043.jpg | 5 | 5 | car×2, person×3 | 1485 | 4.8 |
| voc_000169.jpg | 2 | 2 | car×1, person×1 | 1591 | 2.5 |

合计：{'person': 18, 'car': 7, 'motorcycle': 1, 'bus': 1}

## 3. 语义 vs 实例（同一张图）

- 跨模型 IoU 平均 0.541 / 中位数 0.605（10 组）

| 图像 | FCN前景% | 实例数 | 实例前景% | person实例 | FCN person连通域 | person IoU | 其他类 IoU |
|---|---|---|---|---|---|---|---|
| voc_000302.jpg | 18.6 | 5 | 15.9 | 1 | 1 | 0.336 | car 0.818 |
| bus.jpg | 40.2 | 4 | 34.5 | 3 | 4 | 0.653 | bus 0.758 |
| zidane.jpg | 43.3 | 2 | 37.7 | 2 | 1 | 0.780 | — |
| voc_004091.jpg | 38.8 | 6 | 15.6 | 6 | 4 | 0.556 | — |
| voc_006043.jpg | 51.8 | 6 | 40.5 | 4 | 3 | 0.190 | car 0.662 |
| voc_000169.jpg | 58.1 | 5 | 53.0 | 2 | 2 | 0.269 | car 0.392 |
